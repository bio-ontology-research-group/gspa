import gzip
import hashlib
import json
from pathlib import Path

repo = Path('/home/leechuck/Public/software/gspa')
scratch = Path(__file__).parent
cache = Path.home() / '.cache/gspa-v3-data/nutrient-community-v1'
out = repo / 'benchmark/v3/results/nutrient-community-analysis-v1'
out.mkdir(exist_ok=False)
sources = [(repo / p, 'source/' + p) for p in [
    'benchmark/v3/analyze_nutrient_community.py',
    'benchmark/v3/tests/test_nutrient_community_analysis.py',
    'benchmark/v3/tests/test_nutrient_community.py',
    'benchmark/v3/run_nutrient_community.py',
    'benchmark/v3/run_nutrient_phenotypes.py',
    'docs/benchmarks/v3-nutrient-community-analysis.md',
    'docs/benchmarks/v3-nutrient-community.md',
    'tasks/todo.md', 'tasks/v3-acceptance.md']]
sources += [(p, 'evidence/' + str(p.relative_to(scratch))) for p in sorted(scratch.rglob('*')) if p.is_file()]
sources += [(cache / 'analysis-plan-v1.json', 'freeze/analysis-plan-v1.json'),
            (cache / 'plan-v3/protocol.json', 'freeze/execution-protocol.json')]
sha = lambda b: hashlib.sha256(b).hexdigest()
records = []
for source, logical in sources:
    raw = source.read_bytes()
    target = out / (logical + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    restored = gzip.decompress(target.read_bytes())
    assert restored == raw
    records.append({'source': str(source), 'logical_path': logical,
        'stored_path': str(target.relative_to(out)), 'bytes': len(raw),
        'sha256': sha(raw), 'stored_sha256': sha(target.read_bytes())})
(out / 'index.json').write_text(json.dumps(records, indent=2) + '\n')
verification = {'status': 'analysis_checkpoint_verified', 'payloads':len(records),
    'original_bytes':sum(r['bytes'] for r in records),
    'full_execution_and_empirical_evaluation':'pending', 'whole_item_acceptance':'none',
    'focused_tests':{'run':7,'failures':0}, 'benchmark_tests':{'run':652,'failures':0,'skipped':13},
    'freeze_verified':json.loads((scratch/'freeze-verification.json').read_text())}
(out / 'archive-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
(out / 'README.md').write_text('''# Coculture analysis checkpoint

This archive freezes the dependence-sensitive analysis for all 1,320 coculture
cases and 7,920 execution plans. Full simulation/independent checking is still
running in Slurm array 10150; no empirical accuracy or whole-item acceptance is
claimed. Seven focused tests and the 652-test benchmark gate pass (13 optional
skips). The initial mutable-alias failure and successful repair are retained.

Each payload is gzip-compressed with its original and stored SHA-256 in
`index.json`. `SHA256SUMS` binds every stored file except itself. The unchanged
execution package/models/plans are in the preceding
`nutrient-community-checkpoint-v1` archive. The new freeze binds its exact
execution protocol and source hashes. Results of the full run will be archived
separately.
''')
files=sorted(p for p in out.rglob('*') if p.is_file())
(out/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+str(p.relative_to(out))+'\n' for p in files))
for record in records:
    assert sha(gzip.decompress((out/record['stored_path']).read_bytes()))==record['sha256']
print(json.dumps(dict(verification, checksummed_files=len(files))))
