"""A successful process exit must not certify an incomplete experiment."""
import copy
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import run_source_context_remote as W


class RemoteCompletionTest(unittest.TestCase):
    def setUp(self):
        self.genomes = ['g' + str(i) for i in range(18)]
        exported = dict(status='verified', summaries={a: {**{c: {} for c in W.R.CONTEXTS}, 'comparison': {}}
                                                    for a in W.R.ARMS})
        frozen = dict(status='verified', counts={a: {c: {} for c in W.R.CONTEXTS} for a in W.R.ARMS})
        replayed = dict(status='verified', summaries={a: {c: {k: dict.fromkeys(self.genomes, {})
            for k in W.R.F.KINDS} for c in W.R.CONTEXTS} for a in W.R.ARMS})
        panel = dict(reference_pairs=39, proteins=37, test_genomes=['g0','g1','g2','g3'])
        results = dict(results={p: dict(full_ec_reference={a: copy.deepcopy(panel) for a in W.A.ARMS})
            for p in ('ec_calibration_selected','calibration_selected','fixed_0.5')})
        results['results']['native_emitted_calls'] = dict(full_ec_reference=dict(panel, threshold=0))
        self.args = [exported, frozen, replayed, dict.fromkeys(W.A.ARMS, {}), results, self.genomes]

    def test_complete_experiment(self):
        self.assertEqual(W.completion_counts(*self.args),
            dict(exports=20, fitted_models=40, replayed_genomes=720, analysis_arms=61))

    def test_empty_genome_cannot_disappear_from_replay(self):
        del self.args[2]['summaries']['clean']['SEQONLY']['logistic']['g17']
        with self.assertRaisesRegex(ValueError, 'incomplete replay genomes'):
            W.completion_counts(*self.args)

    def test_incomplete_analysis_and_changed_population_rejected(self):
        for change in ('missing_arm', 'missing_reference', 'native_cut'):
            args = copy.deepcopy(self.args)
            panels = args[4]['results']['ec_calibration_selected']['full_ec_reference']
            if change == 'missing_arm': del panels['clean_native']
            elif change == 'missing_reference': panels['clean_native']['reference_pairs'] = 38
            else: args[4]['results']['native_emitted_calls']['full_ec_reference']['threshold'] = .5
            with self.subTest(change=change), self.assertRaises(ValueError):
                W.completion_counts(*args)

    def test_prerequisite_must_be_bound_and_unchanged(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); prerequisite = root / 'audit.json'; manifest = root / 'packages.sha256'
            prerequisite.write_text('{}'); manifest.write_text('')
            with self.assertRaisesRegex(ValueError, 'unbound prerequisite'):
                W.bindings(manifest, [prerequisite])
            digest = W.R.S.sha(prerequisite)
            manifest.write_text(digest + '  ' + str(prerequisite) + '\n')
            self.assertEqual(W.bindings(manifest, [prerequisite]), {str(prerequisite): digest})
            prerequisite.write_text('{"changed":true}')
            with self.assertRaisesRegex(ValueError, 'unbound prerequisite'):
                W.bindings(manifest, [prerequisite])

    def test_missing_probe_sources_do_not_pass_vacuously(self):
        with self.assertRaisesRegex(ValueError, 'missing probed pipeline sources'):
            W.verify_probe_sources(dict(inputs={},source_root='/scratch/probe/source'))
        prefix = '/scratch/10389/source-probe/source/'
        names = ['benchmark/v3/' + name for name in ('run_source_arm_context_comparison.py',
                 'verified_batch.py', 'cohort_sequence_inputs.py')]
        inputs = {prefix + name: W.R.S.sha(W.ROOT / name) for name in names}
        W.verify_probe_sources(dict(inputs=inputs,source_root=prefix.rstrip('/')))
        inputs[prefix + names[0]] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'probed source changed'):
            W.verify_probe_sources(dict(inputs=inputs,source_root=prefix.rstrip('/')))


if __name__ == '__main__': unittest.main()
