"""Execute the frozen source/context comparison in its restored runtime.

Called by source_context_comparison.sbatch. Preflight verifies the parent data
and numerical runtime without fitting. Full execution also requires the complete
native CLEAN audit and successful real production probe. All stages fail closed;
the scheduler wrapper preserves both failed and completed attempts.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys

import run_source_arm_context_comparison as R
import check_source_arm_context_models as M
import analyze_source_arm_context_models as A

CACHE = Path('/home/leechuck/.cache/gspa-v3-data')
ROOT = Path(__file__).resolve().parents[2]


def completion_counts(exported, frozen, replayed, thresholds, results, genomes):
    """Reject a zero-exit partial workflow, including missing empty-genome runs."""
    for receipt in (exported, frozen, replayed):
        R.require(receipt.get('status') == 'verified', 'unverified stage receipt')
    for tree in (exported['summaries'], frozen['counts'], replayed['summaries']):
        R.require(set(tree) == set(R.ARMS), 'incomplete source arms')
        for arm in R.ARMS:
            required = set(R.CONTEXTS) | ({'comparison'} if tree is exported['summaries'] else set())
            R.require(set(tree[arm]) == required, 'incomplete context arms')
    for contexts in replayed['summaries'].values():
        for kinds in contexts.values():
            R.require(set(kinds) == set(R.F.KINDS), 'incomplete model kinds')
            for records in kinds.values():
                R.require(set(records) == set(genomes), 'incomplete replay genomes')
    R.require(set(thresholds) == set(A.ARMS), 'incomplete frozen thresholds')
    for policy in ('ec_calibration_selected', 'calibration_selected', 'fixed_0.5'):
        panels = results['results'][policy]['full_ec_reference']
        R.require(set(panels) == set(A.ARMS), 'incomplete EC analysis arms')
        for panel in panels.values():
            R.require(panel['reference_pairs'] == 39 and panel['proteins'] == 37 and
                      len(panel['test_genomes']) == 4, 'full EC reference population changed')
    native = results['results']['native_emitted_calls']['full_ec_reference']
    R.require(native['reference_pairs'] == 39 and native['proteins'] == 37 and
              native['threshold'] == 0, 'native emitted-call endpoint changed')
    return dict(exports=20, fitted_models=40, replayed_genomes=40 * len(genomes), analysis_arms=61)


def bindings(path, required):
    bound = {}
    for line in path.read_text().splitlines():
        digest, name = line.split('  ', 1)
        R.require(name not in bound, 'duplicate bundle input')
        bound[name] = digest
    for item in required:
        R.require(bound.get(str(item)) == R.S.sha(item), 'unbound prerequisite: ' + str(item))
    return {str(item): bound[str(item)] for item in required}


def verify_probe_sources(probe, root=ROOT):
    source_root = probe.get('source_root')
    R.require(isinstance(source_root,str) and Path(source_root).is_absolute() and source_root != '/',
              'missing probe source root')
    prefix = source_root.rstrip('/') + '/'
    found = {old[len(prefix):]: digest for old, digest in probe['inputs'].items() if old.startswith(prefix)}
    R.require({'benchmark/v3/' + name for name in ('run_source_arm_context_comparison.py',
        'verified_batch.py', 'cohort_sequence_inputs.py')} <= set(found), 'missing probed pipeline sources')
    for name, digest in found.items():
        R.require(R.S.sha(root / name) == digest, 'probed source changed: ' + name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('preflight', 'full'))
    for key in ('out', 'logs', 'jar', 'clean-root', 'clean-audit', 'probe', 'bindings'):
        parser.add_argument('--' + key, type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    args.logs.mkdir(parents=True, exist_ok=False)
    state = dict(mode=args.mode, job_id=os.environ.get('SLURM_JOB_ID'),
                 hostname=os.uname().nodename, stages=[], status='running')
    completion = None

    def save():
        target = args.logs / 'workflow.json'
        temporary = target.with_suffix('.partial')
        temporary.write_text(json.dumps(state, indent=2) + '\n')
        temporary.replace(target)

    save()
    try:
        required = [args.jar] + ([args.probe, args.clean_audit] if args.mode == 'full' else [])
        prerequisite_inputs = bindings(args.bindings, required)
        training = CACHE / 'observed-gap-models-v1'
        context = CACHE / 'cohort-context-modes-v2-inputs'
        fitting, base, inputs = R.base_inputs(training, context)
        inputs.update(prerequisite_inputs)
        inputs.update(R.C.supervision_inputs(fitting['recipes'],
            json.loads((training / 'registration.json').read_text())['inputs']))
        R.supervision_agreement(fitting['recipes'])
        R.require(len(base['genomes']) == 18, 'complete 18-genome parent required')
        inputs.update(R.F.hashes([args.jar, Path(__file__), *R.C.sources(),
                                 *R.F.V.streaming_parser_sources()]))
        import ijson
        R.require(ijson.__version__ == '3.4.0.post0' and ijson.backend == 'python',
                  'unexpected streaming parser runtime')
        receipt = dict(status='verified', genomes=base['genomes'], inputs=inputs,
                       python=sys.version, numpy=R.F.T.np.__version__,
                       parser=R.F.V.parser_identity(), scope='Parent data and runtime only; no inference or accuracy claim.')
        R.F.save(args.out / 'parent-preflight.json', receipt)
        if args.mode == 'full':
            probe = json.loads(args.probe.read_text())
            R.require(probe.get('schema') == 'gspa.source-context-probe/2' and probe.get('status') == 'verified' and
                      set(probe['summaries']) == {'diamond_homology', 'clean', 'clean_diamond_homology'} and
                      set(probe['historical_model_audit']) == set(R.F.KINDS),
                      'complete three-source production probe required')
            R.require(probe['inputs'].get(str(args.jar)) == R.S.sha(args.jar), 'probe JAR differs')
            verify_probe_sources(probe)
            probe_results = Path(probe['results_root'])
            relocated = {str(args.probe.parent / Path(old).relative_to(probe_results)): digest
                         for old, digest in probe['outputs'].items()}
            R.require(relocated, 'empty probe outputs')
            R.F.check_hashes(relocated)
            inputs.update(relocated)
            R.verify_clean(args.clean_root, args.clean_audit, base['genomes'])
            R.F.save(args.out / 'prerequisites.json', dict(status='verified',
                inputs=R.F.hashes([args.probe, args.clean_audit])))
            learned, replay, analysis = (args.out / x for x in ('training', 'replay', 'analysis'))
            runner = str(ROOT / 'benchmark/v3/run_source_arm_context_comparison.py')
            commands = [('prepare', [sys.executable, runner, 'prepare', '--out', str(learned),
                '--training', str(training), '--context', str(context), '--jar', str(args.jar),
                '--clean-root', str(args.clean_root), '--clean-audit', str(args.clean_audit)])]
            commands += [(action, [sys.executable, runner, action, '--out', str(learned)])
                         for action in ('export', 'train', 'evaluate')]
            commands += [('production-replay', [sys.executable, str(Path(M.__file__)),
                '--training', str(learned), '--out', str(replay)]),
                ('analysis-registration', [sys.executable, str(Path(A.__file__)), 'register',
                 '--training', str(learned), '--replay', str(replay), '--out', str(analysis)]),
                ('analysis', [sys.executable, str(Path(A.__file__)), 'run', '--out', str(analysis)])]
            state['stages'] = [dict(name=name, command=command, status='queued') for name, command in commands]
            save()
            for stage in state['stages']:
                stage.update(status='running', started_at=datetime.now(timezone.utc).isoformat()); save()
                with (args.logs / (stage['name'] + '.log')).open('x') as log:
                    result = subprocess.run(stage['command'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
                stage.update(status='completed' if result.returncode == 0 else 'failed',
                             returncode=result.returncode, finished_at=datetime.now(timezone.utc).isoformat()); save()
                print(json.dumps(stage), flush=True)
                if result.returncode:
                    raise RuntimeError('stage failed: ' + stage['name'])
                # A checkpoint is partial until final verification and publication.
                subprocess.run(['rsync', '-a', str(args.out) + '/',
                                str(args.logs.parent / 'checkpoint') + '/'], check=True)
            read = lambda path: json.loads(path.read_text())
            exported, frozen = (read(learned / name) for name in ('export.json', 'training.json'))
            replayed = read(replay / 'verification.json')
            analysis_verified = read(analysis / 'verification.json')
            R.require(analysis_verified.get('status') == 'verified', 'unverified analysis')
            counts = completion_counts(exported, frozen, replayed, read(analysis / 'thresholds.json'),
                                       read(analysis / 'results.json'), base['genomes'])
            for arm in R.ARMS:
                for context_name in R.CONTEXTS:
                    for kind in R.F.KINDS:
                        model = learned / arm / context_name / 'models' / ('model_' + kind + '.json')
                        R.require(frozen['outputs'].get(str(model)) == R.S.sha(model), 'missing or changed frozen model')
            receipt_paths = [learned / name for name in ('protocol.json', 'registration.json', 'export.json', 'training.json', 'evaluation.json')]
            receipt_paths += [replay / 'verification.json'] + [analysis / name for name in
                ('protocol.json', 'registration.json', 'thresholds.json', 'results.json', 'verification.json')]
            completion = dict(status='verified', counts=counts,
                              receipts=R.F.hashes(receipt_paths), model_promotion='none')
        R.F.check_hashes(inputs)
        if completion is not None:
            R.F.save(args.out / 'final-receipt.json', completion)
        state['status'] = 'verified'
    except BaseException as error:
        state.update(status='failed', error=str(error))
        raise
    finally:
        state['finished_at'] = datetime.now(timezone.utc).isoformat()
        save()


if __name__ == '__main__':
    main()
