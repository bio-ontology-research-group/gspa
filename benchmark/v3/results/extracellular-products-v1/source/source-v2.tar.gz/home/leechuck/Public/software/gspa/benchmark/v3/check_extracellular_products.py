#!/usr/bin/env python3
"""Real-model secretion route check; not measured production or function recovery."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'scripts'), str(Path(__file__).parent)]
import metabolic_experiments as ME
import masked_assignment_experiments as MA
import check_masked_assignment_cobra as CO
import run_germicidin_diagnostic as GD
import cobra

PRODUCTS = ['R_EX_act_e', 'R_EX_gACT_e']
GENE = 'G_SCO5089'


def save(path, value):
    with path.open('x') as f:
        f.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def check(model_path, medium, out):
    out.mkdir(exist_ok=False)
    model = ME.load_sbml_model(model_path)
    base = GD.manifest(model, medium, 'published_model_minimal')
    base['config'].update(strategy='fixed', product_requirement='maintenance_only',
        max_experiments=40, max_solver_calls=500, max_focus_reactions=0, max_baseline_focus_reactions=0)
    base['context'] = {'hypotheses': [{'id': 'H', 'gene': GENE}], 'evidence': [
        {'id': f'E{i}_{j}', 'type': 'bgc', 'hypothesis_id': 'H', 'product_exchange': product,
         'condition_hint': 'supplement_removal', 'exchange': nutrient}
        for i, product in enumerate(PRODUCTS) for j, nutrient in enumerate(['R_EX_pi_e', 'R_EX_glc__D_e'])]}
    masked = copy.deepcopy(base)
    masked['context'] = {}
    masked['assignment_recovery'] = {'mask_gene': GENE,
        'hypotheses': [{'id': 'H0', 'assignments': {}},
                       {'id': 'H1', 'assignments': {'R_ACTS1': [[MA.TARGET]]}},
                       {'id': 'H2', 'assignments': {'R_GERMA': [[MA.TARGET]]}}],
        'conditions': [{'id': 'C' + str(i * 3 + j), 'mods': mods, 'product_exchange': product,
                        'evidence_channels': ['bgc']}
            for i, product in enumerate(PRODUCTS) for j, mods in enumerate([
                [], [{'op': 'close', 'exchange': 'R_EX_pi_e'}],
                [{'op': 'close', 'exchange': 'R_EX_glc__D_e'}]])]}
    save(out / 'registration.json', {'model_sha256': hashlib.sha256(model_path.read_bytes()).hexdigest(),
        'medium_sha256': hashlib.sha256(medium.read_bytes()).hexdigest(), 'standard': base, 'masked': masked,
        'scope': 'Pinned Sco-GEM mechanism check with controlled hypotheses; no assay outcomes, independent function truth, or discovery score.'})
    original = cobra.io.read_sbml_model(model_path, f_replace={})
    original.solver = 'glpk'
    result = ME.run_experiments(base, model)
    save(out / 'standard-result.json', result)
    items = {r['id']: r for r in result['menu']}
    comparisons = []
    for row in result['experiments']:
        if not row['experiment_id'].startswith('product:'):
            continue
        item = items[row['experiment_id']]
        expected = CO.simulate(original, base, {'assignments': {}}, item, result['config'], False)
        measured = row['measurements'].get('product', {})
        interval = expected.get('product_interval')
        if interval and interval['statuses'] == ['optimal', 'optimal']:
            match = (CO.agrees(row['measurements']['max_growth'], expected['growth']) and
                     CO.agrees(measured.get('max_secretion'), max(0, interval['maximum'])) and
                     CO.agrees(measured.get('min_secretion_at_required_state'), max(0, interval['minimum'])))
        else:
            match = (expected['status'] == 'infeasible' and row.get('outcome') == 'infeasible_with_maintenance'
                     and 'max_secretion' not in measured)
        comparisons.append({'experiment': row['experiment_id'], 'agrees': match, 'oracle': expected,
                            'production': row})
    save(out / 'standard-oracle.json', comparisons)
    assert len(comparisons) == 8 and all(r['agrees'] for r in comparisons), 'standard secretion comparison failed'
    result = ME.run_experiments(masked, model)
    save(out / 'masked-result.json', result)
    report = CO.compare(model_path, masked, result)
    save(out / 'masked-oracle.json', report)
    assert len(result['cells']) == 18
    assert report['n_agree'] == report['n_comparisons'] == 36
    assert report['n_cell_agree'] == report['n_cell_comparisons'] == 18
    summary = {'status': 'verified', 'standard_product_comparisons': len(comparisons),
               'masked_phenotype_comparisons': report['n_comparisons'], 'masked_cell_comparisons': report['n_cell_comparisons'],
               'scope': 'Independent numerical agreement only; no measured-production accuracy or recovered-function claim.'}
    save(out / 'verification.json', summary)
    return summary


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for key in ('model', 'medium', 'out'):
        p.add_argument('--' + key, required=True, type=Path)
    args = p.parse_args()
    print(json.dumps(check(args.model, args.medium, args.out), sort_keys=True))
