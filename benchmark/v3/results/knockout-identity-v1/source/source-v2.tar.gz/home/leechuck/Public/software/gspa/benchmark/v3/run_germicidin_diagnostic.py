#!/usr/bin/env python3
"""Known-GPR perturbation and intracellular capacity on unmodified Sco-GEM.

Not an experiment-medium reconstruction, extracellular production prediction or
function recovery benchmark. Run on a compute node. No observation file is read.
"""
import argparse
import copy
import csv
import hashlib
import json
import math
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'scripts'))
import metabolic_experiments as ME
import numpy as np
import cobra

GENE = 'G_SCO7221'
BIO = 'R_BIOMASS_SCO_tRNA'
PRODUCTS = ['R_DM_germicidin' + c + '_c' for c in 'ABCD']
PROTOCOL = {'schema': 'gspa.germicidin_capacity_diagnostic/1',
    'conditions': ['published_model_minimal', 'phosphate_closed', 'carbon_closed'],
    'genotypes': ['native', 'gcs_deleted', 'gcs_restored'],
    'requirements': ['growth_fraction', 'maintenance_only'], 'growth_fraction': .95,
    'growth_threshold': 1e-6, 'flux_tolerance': 1e-7, 'max_solver_calls': 500,
    'product_targets': PRODUCTS, 'biomass': BIO, 'maintenance': {'reaction': 'R_ATPM', 'lower_bound': 2.64},
    'native_gene': GENE,
    'limitations': ['Known source GPRs; no masked discovery or gene assignment accuracy.',
        'The bundled model minimal medium is not the experimental complex GYM medium.',
        'Phosphate/carbon closure are declared model interventions, not the published batch time course.',
        'Intracellular demand flux is synthesis capacity, not extracellular secretion or expression.',
        'Source-model A/B/C/D congeners are not assumed to match the publication A/B7 labels.',
        'Restored means restoring native reaction availability, not modelling plasmid copy number or regulation.',
        'The source model is M145, not a complete reconstruction of M1152 or M1317.']}


def manifest(model, medium_path, condition):
    with medium_path.open() as handle:
        rows = list(csv.DictReader(handle, skipinitialspace=True))
    medium = {'R_' + row['exchange'].strip(): -float(row['uptake']) for row in rows}
    if condition == 'phosphate_closed':
        medium.pop('R_EX_pi_e')
    elif condition == 'carbon_closed':
        medium.pop('R_EX_glc__D_e')
    external = [r for r in model.rxn_ids if model.is_single_metabolite(r)
                and model.met_compartment[model.exchange_metabolite(r)] == 'e']
    return {'model': model.path, 'objectives': {'biomass': BIO, 'maintenance': PROTOCOL['maintenance']},
            'baseline': {'medium': medium, 'exchanges': external, 'carbon_exchanges': ['R_EX_glc__D_e']},
            'context': {}, 'config': {'max_solver_calls': PROTOCOL['max_solver_calls'],
                'max_focus_reactions': 0, 'growth_fraction': PROTOCOL['growth_fraction']}}


def oracle(original, m, genotype, requirement):
    """Independent parser/GPR deletion, bounds construction and GLPK objectives."""
    other = original.copy()
    medium = m['baseline']['medium']
    for r in other.reactions:
        if len(r.metabolites) == 1:
            coefficient = next(iter(r.metabolites.values()))
            lo, hi = r.bounds
            r.bounds = ((-medium[r.id] if r.id in medium else max(0, lo)), hi) if coefficient < 0 else (
                lo, medium[r.id] if r.id in medium else min(0, hi))
    atpm = other.reactions.get_by_id('R_ATPM')
    atpm.lower_bound = max(atpm.lower_bound, PROTOCOL['maintenance']['lower_bound'])
    if genotype == 'gcs_deleted':
        other.genes.get_by_id(GENE).knock_out()
    bio = other.reactions.get_by_id(BIO)
    other.objective = bio; other.objective_direction = 'max'
    growth = other.slim_optimize()
    out = {'growth_status': other.solver.status,
           'growth': float(growth) if other.solver.status == 'optimal' else None, 'capacities': {}}
    if out['growth_status'] != 'optimal' or (requirement == 'growth_fraction' and growth <= PROTOCOL['growth_threshold']):
        return out
    if requirement == 'growth_fraction':
        bio.lower_bound = max(bio.lower_bound, PROTOCOL['growth_fraction'] * growth)
    for rid in PRODUCTS:
        rxn = other.reactions.get_by_id(rid)
        sign = -float(np.sign(next(iter(rxn.metabolites.values()))))
        values, statuses = [], []
        for sense in ('min', 'max'):
            other.objective = other.problem.Objective(sign * rxn.flux_expression, direction=sense)
            value = other.slim_optimize(); statuses.append(other.solver.status)
            values.append(float(value) if other.solver.status == 'optimal' else None)
        out['capacities'][rid] = {'minimum': values[0], 'maximum': values[1], 'statuses': statuses}
    return out


def production(model, m, genotype, requirement):
    run = ME.Runner(model, m, ME.resolve_config(m))
    lb, ub = run.base_lb.copy(), run.base_ub.copy()
    mods = [{'op': 'knockout', 'genes': [GENE], 'reactions': []}] if genotype == 'gcs_deleted' else []
    killed = ME.apply_mods(model, m, run.cfg, lb, ub, mods, run.external)
    g, growth = run._growth(lb, ub, 'growth')
    out = {'growth_status': g.status, 'growth': growth if g.status == 'optimal' else None, 'capacities': {}}
    if g.status == 'optimal' and (requirement == 'maintenance_only' or growth > PROTOCOL['growth_threshold']):
        if requirement == 'growth_fraction':
            lb = run._fixed_growth_lb(lb, growth)
        for rid in PRODUCTS:
            col, _ = model.exchange(rid)
            assert model.met_compartment[model.exchange_metabolite(rid)] == 'c'
            c = np.zeros(len(model.rxn_ids)); c[col] = model.secretion_sign(rid)
            lo = run.solver.optimize(c, lb, ub, rid + ':min')
            hi = run.solver.optimize(-c, lb, ub, rid + ':max')
            out['capacities'][rid] = {'minimum': lo.objective if lo.status == 'optimal' else None,
                'maximum': -hi.objective if hi.status == 'optimal' else None, 'statuses': [lo.status, hi.status]}
    return out, killed, run.solver.log


def agree(a, b):
    if isinstance(a, dict):
        return isinstance(b, dict) and set(a) == set(b) and all(agree(a[k], b[k]) for k in a)
    if isinstance(a, (float, int)) and not isinstance(a, bool):
        return isinstance(b, (float, int)) and math.isclose(a, b, rel_tol=1e-6, abs_tol=1e-7)
    return a == b


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('model', 'medium', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    args = p.parse_args(); args.out.mkdir(parents=True, exist_ok=False)
    def save(name, data):
        (args.out / name).write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')
    # Freeze the declared plan and actual input bytes before any LP is solved.
    save('protocol.json', {**PROTOCOL, 'model_sha256': hashlib.sha256(args.model.read_bytes()).hexdigest(),
                          'medium_sha256': hashlib.sha256(args.medium.read_bytes()).hexdigest()})
    model = ME.load_sbml_model(args.model)
    other = cobra.io.read_sbml_model(args.model, f_replace={}); other.solver = 'glpk'
    rows = []
    for condition in PROTOCOL['conditions']:
        m = manifest(model, args.medium, condition)
        save('manifest-' + condition + '.json', m)
        for genotype in PROTOCOL['genotypes']:
            for requirement in PROTOCOL['requirements']:
                actual, killed, calls = production(model, m, genotype, requirement)
                expected = oracle(other, m, genotype, requirement)
                rows.append({'condition': condition, 'genotype': genotype, 'requirement': requirement,
                             'production': actual, 'oracle': expected, 'knocked_out_reactions': killed,
                             'solver_calls': calls, 'agrees': agree(actual, expected)})
                save('results.json', rows)
    # Known-GPR expectations are mechanism tests, not independent function truth.
    for row in rows:
        if row['genotype'] == 'gcs_deleted':
            assert row['knocked_out_reactions'] == ['R_GERMA', 'R_GERMB', 'R_GERMC', 'R_GERMD']
            for capacity in row['production']['capacities'].values():
                if capacity['statuses'] == ['optimal', 'optimal']:
                    assert abs(capacity['maximum']) < PROTOCOL['flux_tolerance']
        elif row['genotype'] == 'gcs_restored':
            native = next(r for r in rows if r['condition'] == row['condition'] and r['requirement'] == row['requirement'] and r['genotype'] == 'native')
            assert row['production'] == native['production']
    save('summary.json', {'scenarios': len(rows), 'oracle_agreements': sum(r['agrees'] for r in rows),
        'production_lp_calls': sum(len(r['solver_calls']) for r in rows), 'protocol': PROTOCOL,
        'scope': 'Known-GPR, intracellular-capacity mechanism diagnostic. No empirical production or function-recovery accuracy.'})
    assert all(r['agrees'] for r in rows), 'independent solver disagreement retained'
    print(json.dumps({'scenarios': len(rows), 'oracle_agreements': sum(r['agrees'] for r in rows)}))


if __name__ == '__main__':
    main()
