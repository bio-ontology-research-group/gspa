#!/usr/bin/env python3
"""Controlled native-process fixture; does not execute a geNomad model."""
import hashlib,json,os,sys
from pathlib import Path
mode=os.environ['GSPA_NATIVE_MODE']
fasta,out=Path(sys.argv[-3]),Path(sys.argv[-2])
assert sys.argv[1]=='end-to-end' and '--threads' in sys.argv
assert fasta.read_text().startswith('>ctg|original\n')
summary=out/(fasta.stem+'_summary');summary.mkdir()
virus='seq_name\tlength\ttopology\tcoordinates\tvirus_score\ttaxonomy\n'
plasmid='seq_name\tlength\ttopology\tplasmid_score\n'
if mode=='valid':
 virus+='ctg|original\t100\tDTR\tNA\t0\ttaxon\nctg|original|provirus_2_11\t10\tProvirus\t2-11\t0.9\ttaxon\n'
 plasmid+='ctg|original\t100\tDTR\t1\n'
elif mode=='partial':virus+='ctg|original\t100\tDTR\tNA\t0.9\ttaxon\n'
elif mode in ('nan','infinite'):
 score='NaN' if mode=='nan' else 'inf'
 virus+=f'ctg|original\t100\tDTR\tNA\t{score}\ttaxon\n'
elif mode=='header':virus='wrong\theader\n'
if mode not in ('missing','nonzero'):
 (summary/(fasta.stem+'_virus_summary.tsv')).write_text(virus)
 if mode!='partial':(summary/(fasta.stem+'_plasmid_summary.tsv')).write_text(plasmid)
Path(os.environ['GSPA_NATIVE_MARKER']).write_text(json.dumps({'mode':mode,'command':sys.argv,'outputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in summary.iterdir()}})+'\n')
if mode=='nonzero':
 print('controlled native failure',file=sys.stderr)
 sys.exit(7)
