"""Production JVM -> real sidecar -> controlled native process contract replay."""
import hashlib,json,os,shutil,subprocess,sys,zipfile
from pathlib import Path
from urllib.parse import unquote
root=Path(sys.argv[1]);root.mkdir()
package=Path(__file__).parent
repo=Path('/home/leechuck/Public/software/gspa')
engines={'before':package/'before.jar','after':package/'after.jar'}
sidecars={'before':package/'sidecar.before.py','after':repo/'benchmark/neural/run_genomic_predictors.py'}
fixtures=package/'native-bin';fixtures.mkdir()
shutil.copyfile(package/'native-fixture.py',fixtures/'genomad');(fixtures/'genomad').chmod(0o755)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
(root/'genome.fna').write_text('>ctg|original\n'+'A'*100+'\n')
(root/'empty.gff3').write_text('##gff-version 3\n')
write(root/'integration.json',{'lite':True,'enabledPriors':'none'})
registered=[]
for version in engines:
 for mode in ['valid','zero','missing','partial','nan','infinite','header','nonzero']:
  run=root/(version+'_'+mode);run.mkdir()
  config={'predictors':{'similarity':{'enabled':False},'domains':{'enabled':False},'pathway':{'enabled':False},'operons':{'enabled':False},'viral':{'genomicSidecar':str(sidecars[version]),'pythonExecutable':sys.executable,'genomad':{'enabled':True,'dbPath':'controlled-native-fixture','minScore':0.0}}},'quality':{'enabled':False}}
  write(run/'config.json',config)
  command=['java','-jar',str(engines[version]),'annotate','--genome',str(root/'genome.fna'),'--gff3',str(root/'empty.gff3'),'--config',str(run/'config.json'),'--output',str(run/'out'),'--claims-out',str(run/'claims.jsonl'),'--integration-config',str(root/'integration.json'),'--no-metrics','--threads','1']
  registered.append({'version':version,'mode':mode,'command':command,'run':str(run),'config_sha256':sha(run/'config.json')})
write(root/'registration.json',{'scope':'controlled native process, no geNomad model execution or accuracy claim','engines':{k:sha(p) for k,p in engines.items()},'sidecars':{k:sha(p) for k,p in sidecars.items()},'native_fixture_sha256':sha(fixtures/'genomad'),'replay_sha256':sha(Path(__file__)),'runs':registered})
results=[]
for record in registered:
 run=Path(record['run']);version=record['version'];mode=record['mode']
 env=dict(os.environ,PATH=str(fixtures)+os.pathsep+os.environ['PATH'],GSPA_NATIVE_MODE=mode,GSPA_NATIVE_MARKER=str(run/'native.json'))
 with (run/'stdout.log').open('w') as stdout,(run/'stderr.log').open('w') as stderr:
  p=subprocess.run(record['command'],env=env,stdout=stdout,stderr=stderr,timeout=120)
 write(run/'receipt.json',{'returncode':p.returncode,'command':record['command']})
 assert p.returncode==0,(record,p.returncode)
 assert (run/'native.json').is_file()
 manifest=json.loads(next((run/'out').glob('*_predictor_status.json')).read_text())
 status=manifest['predictors'][0];assert status['predictor']=='genomad'
 expected={'valid':'SUCCESS','zero':'SUCCESS_ZERO','missing':'SUCCESS_ZERO','partial':'SUCCESS','nan':'SUCCESS_ZERO','infinite':'SUCCESS','header':'SUCCESS_ZERO','nonzero':'FAILED'}[mode]
 if version=='after' and mode not in ('valid','zero'):expected='FAILED'
 assert status['outcome']==expected,(record,status)
 rows=[line.split('\t') for line in next((run/'out').glob('*.gff3')).read_text().splitlines() if '\t' in line and not line.startswith('#')]
 expected_count=3 if mode=='valid' else (1 if version=='before' and mode in ('partial','infinite') else 0)
 assert len(rows)==expected_count,(record,rows)
 assert all(row[2]=='region' for row in rows)
 if mode=='valid':
  assert [tuple([unquote(r[0])]+r[3:6]) for r in rows]==[('ctg|original','1','100','0.0'),('ctg|original','2','11','0.9'),('ctg|original','1','100','1.0')]
 assert (run/'claims.jsonl').read_text()==''
 assert list((run/'out').glob('*.stages.json'))
 results.append({'version':version,'mode':mode,'status':status,'regions':len(rows),'files':{str(p.relative_to(run)):sha(p) for p in run.rglob('*') if p.is_file()}})
for mode in ('valid','zero','nonzero'):
 a=next((root/('before_'+mode)/'out').glob('*.gff3'))
 b=next((root/('after_'+mode)/'out').glob('*.gff3'))
 assert a.read_bytes()==b.read_bytes(),mode
# Check the standalone JAR carries the exact repaired sidecar too.
with zipfile.ZipFile(engines['after']) as jar:
 import io
 with zipfile.ZipFile(io.BytesIO(jar.read('downloads/gspa-resources.pyz'))) as resource:
  assert resource.read('bundled/sidecars/run_genomic_predictors.py')==sidecars['after'].read_bytes()
write(root/'verification.json',{'status':'verified','runs':results,'bundled_sidecar_matches':True})
print('Verified 16 production CLI/native-process fixture runs and bundled sidecar bytes.')
