import csv, hashlib, json, os, signal, subprocess, sys, time
from pathlib import Path
root=Path(sys.argv[1]); out=root/'results'; out.mkdir(); (out/'tmp').mkdir()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def fasta(p):
    result={}
    for block in p.read_text().split('>'):
        if not block: continue
        lines=block.splitlines(); h=lines[0].split(' # '); pid=h[0].split()[0]
        assert pid not in result
        result[pid]=dict(sequence=''.join(lines[1:]), contig=pid.rsplit('_',1)[0], start=int(h[1]), end=int(h[2]), strand='+' if h[3]=='1' else '-')
    return result
runs=[]; summary={}; bindings={str(root/'gspa.jar'):sha(root/'gspa.jar'),str(Path(__file__)):sha(Path(__file__))}
for caller in ['pyrodigal','prodigal']:
    for mode in ['single','meta']:
        name=caller+'-'+mode; folder=root/caller; gff=folder/('genome-'+mode+'.gff'); faa=gff.with_suffix('.faa'); genome=folder/'inputs/genome.fna'
        for p in [gff,faa,genome]: bindings[str(p)]=sha(p)
        ref=fasta(faa)
        native_cds=[r.split('\t') for r in gff.read_text().splitlines() if r and not r.startswith('#')]
        assert {(r[0],int(r[3]),int(r[4]),r[6]) for r in native_cds if r[2]=='CDS'} == {(r['contig'],r['start'],r['end'],r['strand']) for r in ref.values()}
        config=out/(name+'.json'); config.write_text(json.dumps(dict(input=dict(kingdom='bacteria',type='genome'), predictors={k:dict(enabled=k=='operons') for k in ['similarity','domains','pathway','operons','localization']},integration=dict(enabled=False),quality=dict(enabled=False))))
        bindings[str(config)]=sha(config)
        cmd=['/usr/lib/jvm/java-21-openjdk-amd64/bin/java','-XX:ActiveProcessorCount=3','-jar',str(root/'gspa.jar'),'annotate','--genome',str(genome),'--gff3',str(gff),'--proteins',str(faa),'--config',str(config),'--output',str(out/name),'--threads','1','--no-metrics']
        start=time.monotonic()
        with (out/(name+'.log')).open('w') as log:
            proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,TMPDIR=str(out/'tmp'),JAVA_TOOL_OPTIONS='-Djava.io.tmpdir='+str(out/'tmp')))
            try: proc.wait(timeout=300)
            except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL); proc.wait()
        runs.append(dict(name=name,command=cmd,exit_code=proc.returncode,seconds=time.monotonic()-start)); (out/'runs.json').write_text(json.dumps(runs,indent=2))
        assert proc.returncode==0, name
        rows=list(csv.DictReader((out/name/(gff.stem+'_proteins.tsv')).open(),delimiter='\t'))
        assert len(rows)==len(ref) and {r['protein_id'] for r in rows}==set(ref)
        placed=[r for r in rows if r['contig']!='unplaced']
        correct=[r for r in placed if (r['contig'],int(r['start']),int(r['end']),r['strand'])==(ref[r['protein_id']]['contig'],ref[r['protein_id']]['start'],ref[r['protein_id']]['end'],ref[r['protein_id']]['strand'])]
        ops=out/name/'operons.tsv'; members=out/name/'protein_to_operon.tsv'
        summary[name]=dict(total=len(ref),placed=len(placed),correct_coordinates=len(correct),unplaced=len(rows)-len(placed),operons=len(ops.read_text().splitlines())-1 if ops.exists() else 0,operon_members=len(members.read_text().splitlines())-1 if members.exists() else 0)
        (out/'summary.json').write_text(json.dumps(summary,indent=2))
assert all(sha(Path(p))==h for p,h in bindings.items())
(out/'inputs.sha256.json').write_text(json.dumps(bindings,indent=2)); print(json.dumps(summary,indent=2))
