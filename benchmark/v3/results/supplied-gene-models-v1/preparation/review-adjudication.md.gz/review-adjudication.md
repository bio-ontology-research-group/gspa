# Supplied gene-model review dispositions

Two read-only Claude Sonnet 5.5 reviews were completed.

Applied: preserve headers; share the coordinate-constrained identity resolver;
use all aliases; retain unplaced proteins; collision-safe synthetic contig names;
reject duplicate protein IDs; deterministic representative segment; detect
conflicts over every segment of a grouped protein. Final v3 adds regression
coverage for duplicate native CDS rows, same-start segments, opposite strands,
and segment-specific aliases competing with a grouped protein.

Rejected: alias-first matching (native numeric contig collisions require coordinate
filtering first); global coordinate-only matching (coordinates do not establish
identity); claimed whitespace-reader disagreement (FastaReader trims each line).
The requested contig-suffix case is already tested using long_contig_5_1.

Limitations retained: general multi-row transcript/span construction is outside
this join repair; identical declared protein identities can group distinct loci
when the input misidentifies them. Malformed numeric metadata can reject the
input; tolerating incomplete annotation is not a promise to accept invalid
numeric data. Existing per-contig linear lookup is unchanged.

Evidence: original complete native outputs verified through CLI10523; final
17 regressions produce14 old-source failures,67 focused cases pass10526.
Final full gate and ten actual CLI outcomes are recorded in the main report.
