"""Controlled adapter-contract fixture, not geNomad or biological evidence."""
import argparse, csv, json, os
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--manifest'); p.add_argument('--predictor'); p.add_argument('--min-score'); p.add_argument('--db-path')
a=p.parse_args()
r=list(csv.DictReader(Path(a.manifest).open(),delimiter='\t'))
assert len(r)==1 and a.predictor=='genomad'
r=r[0]
assert Path(r['genome_fasta']).read_text().startswith('>ctg\n')
Path(os.environ['GSPA_REPLAY_CALL']).write_text(json.dumps({'mode':a.db_path,'manifest':r}))
if a.db_path != 'missing':
 out=Path(r['output_dir'])/(r['tag']+'.genomad.genomic.tsv')
 text='contig_id\tregion_start\tregion_end\tregion_type\tscore\tattributes\n'
 if a.db_path=='hit': text+='ctg\t2\t270\tviral_contig\t0.0\tdescription=a;b=c,d% +|count=0\n'
 out.write_text(text)
