"""Registered real CLI executions with a controlled genomic sidecar fixture."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
from urllib.parse import unquote
root=Path(sys.argv[1]); root.mkdir(parents=True,exist_ok=True)
jars=dict(zip(['original','dispatch','final'],map(Path,sys.argv[2:5])))
fixture=Path('/home/leechuck/tmp/gspa-genomic-output-v1/fixture.py')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x): p.write_text(json.dumps(x,indent=2)+'\n')
base=root/'inputs';base.mkdir()
(base/'genome.fna').write_text('>ctg\n'+'ATG'*100+'\n')
(base/'empty.gff3').write_text('##gff-version 3\n')
(base/'overlap.gff3').write_text('##gff-version 3\nctg\tfixture\tCDS\t1\t90\t.\t+\t0\tID=cds1\nctg\tfixture\tCDS\t151\t240\t.\t+\t0\tID=cds2\n')
write(base/'integration.json',{'lite':True,'enabledPriors':'none'})
cases=[('no_cds_hit','empty','hit'),('overlap_hit','overlap','hit'),('no_cds_zero','empty','zero'),('no_cds_missing','empty','missing')]
registered=[]
for version,jar in jars.items():
 for name,gff,mode in cases:
  run=root/(version+'_'+name);run.mkdir()
  config={'predictors':{'similarity':{'enabled':False},'domains':{'enabled':False},'pathway':{'enabled':False},'operons':{'enabled':True},'viral':{'genomicSidecar':str(fixture),'pythonExecutable':sys.executable,'genomad':{'enabled':True,'dbPath':mode,'minScore':0.0}}},'quality':{'enabled':False}}
  write(run/'config.json',config)
  cmd=['java','-jar',str(jar),'annotate','--genome',str(base/'genome.fna'),'--gff3',str(base/(gff+'.gff3')),'--config',str(run/'config.json'),'--output',str(run/'output'),'--claims-out',str(run/'claims.jsonl'),'--integration-config',str(base/'integration.json'),'--no-metrics','--threads','1']
  registered.append({'version':version,'case':name,'gff':gff,'mode':mode,'run':str(run),'command':cmd,'config_sha256':digest(run/'config.json'),'marker':str(run/'invoked.json')})
write(root/'registration.json',{'scope':'controlled contract fixture; no biological accuracy claim','engines':{k:{'path':str(v),'sha256':digest(v)} for k,v in jars.items()},'fixture_sha256':digest(fixture),'inputs':{p.name:digest(p) for p in base.iterdir()},'runs':registered})
results=[]
for record in registered:
 run=Path(record['run']); env=dict(os.environ,GSPA_REPLAY_CALL=record['marker'])
 with (run/'stdout.log').open('w') as out,(run/'stderr.log').open('w') as err:
  completed=subprocess.run(record['command'],env=env,stdout=out,stderr=err,timeout=120)
 write(run/'receipt.json',{'returncode':completed.returncode,'command':record['command']})
 assert completed.returncode==0,(record,completed.returncode)
 output=run/'output'
 manifest=json.loads(next(output.glob('*_predictor_status.json')).read_text())
 statuses={p['predictor']:p for p in manifest['predictors']}
 lines=next(output.glob('*.gff3')).read_text().splitlines()
 rows=[x.split('\t') for x in lines if not x.startswith('#') and '\t' in x]
 regions=[r for r in rows if r[2]=='region']
 original_empty=record['version']=='original' and record['gff']=='empty'
 assert Path(record['marker']).exists() != original_empty
 if original_empty:
  assert not statuses and not regions
  assert not list(output.glob('*.stages.json'))
 else:
  expected={'hit':'SUCCESS','zero':'SUCCESS_ZERO','missing':'FAILED'}[record['mode']]
  assert statuses['genomad']['outcome']==expected,statuses
  assert statuses['genomad']['annotation_count']==(1 if record['mode']=='hit' else 0)
  if record['gff']=='empty':
   assert statuses['operon']['outcome']=='SKIPPED',statuses
   assert (run/'claims.jsonl').read_text()==''
  assert list(output.glob('*.stages.json')),list(output.iterdir())
 if record['version']=='final' and record['mode']=='hit':
  assert len(regions)==1,regions
  r=regions[0];assert r[:8]==['ctg','genomad','region','2','270','0.0','.','.'],r
  attrs=dict(x.split('=',1) for x in r[8].split(';'))
  attrs={k:unquote(v) for k,v in attrs.items()}
  assert attrs['annotation_type']=='VIRAL_CONTIG' and attrs['evidence_type']=='GENOMIC_REGION_ML'
  assert json.loads(attrs['metadata'])['description']=='a;b=c,d% +'
  assert not ({'Parent','Derives_from'} & attrs.keys())
  assert lines.index('\t'.join(r))<lines.index('##FASTA')
 else: assert not regions,regions
 assert sum(r[2]=='CDS' for r in rows)==(2 if record['gff']=='overlap' else 0)
 results.append({'version':record['version'],'case':record['case'],'regions':len(regions),'statuses':statuses,'files':{str(p.relative_to(run)):digest(p) for p in run.rglob('*') if p.is_file()}})
# The writer repair changes only the GFF on hit cases. Empty/failed scans keep
# identical GFF, and raw claims and integrated tables remain identical always.
for name,_,mode in cases:
 a=root/('dispatch_'+name);b=root/('final_'+name)
 assert (a/'claims.jsonl').read_bytes()==(b/'claims.jsonl').read_bytes()
 for old in (a/'output').glob('*_integrated.tsv'):
  assert old.read_bytes()==(b/'output'/old.name).read_bytes()
 if mode!='hit':
  old=next((a/'output').glob('*.gff3'))
  assert old.read_bytes()==(b/'output'/old.name).read_bytes()
write(root/'verification.json',{'status':'verified','runs':results})
print('Verified 12 production CLI runs; controlled fixture, no biological validation.')
